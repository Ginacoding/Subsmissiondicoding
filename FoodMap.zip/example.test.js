const JohnDoe = 'John Doe';
 
describe('Scenario Test Example', () => {
  it('test case example', () => {
    expect(JohnDoe).toEqual('John Doe');
  });
});