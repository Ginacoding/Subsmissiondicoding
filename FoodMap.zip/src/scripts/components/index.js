// src/scripts/components/index.js
import './hero-element.js'; // Pastikan tidak ada './components/' di sini
import './restaurant-list.js';
import './footer.js';
import './card-item.js';
import './loader-element.js';
